import moment from 'moment'; // Example for onSort prop
import React, { Component } from 'react'; // Import React
import axios from 'axios';
import {Link, withRouter} from 'react-router-dom';
import { render } from 'react-dom'; // Import render method
import Datatable from 'react-bs-datatable'; // Import this package
import swal from 'sweetalert';
import {  Modal,ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import './datatable.css';
const URL = process.env.REACT_APP_LOCAL;

 
class BrandDataTable extends Component{ 
    constructor(props){
        super(props);
        this.state = {
        brandList : [],  
        }
    this.fetchBrand = this.fetchBrand.bind(this);
      }
        componentWillMount(){
          this.fetchBrand();
        }

        fetchBrand(){
            axios.post(URL+'/api/fetchBrands').then((resp)=>{
              console.log('OOOOOOOOOOOOOOOO',resp.data.doc);
              this.setState({
                brandList : resp.data.doc,
              })
            })
          }

          deleteSubCategory(e){
            swal({
              title: "Are you sure?",
              text: "Once deleted, you will not be able to recover this imaginary file!",
              icon: "warning",
              buttons: true,
              dangerMode: true,
            }).then((willDelete)=>{
              if(willDelete){
                axios.post(URL+'/api/deleteSubCategory',{
                  businessId: e,
                }).then(res=>{
                  swal("Poof! Your imaginary file has been deleted!",{
                    icon:"success",
                  });
                })
                setTimeout(function(){
                  return window.location = '/subcategory';
                },2000)
              }else{
                swal("Your imaginary file is safe!");
              }
            });
           }


render(){
  console.log('!!!!!!!!!!!!!!!!!!!!!!!!!',this.state.brandList);
const header = [
  { title: 'Brand', prop: 'brand', sortable: true, filterable: true },
  // { title: 'Image', prop: 'image', sortable: true, filterable: true },
  // { title: 'Status', prop: 'status', sortable: true ,filterable: true},
  { title: 'Action', prop: 'action'    ,sortable: true , filterable: true },
  ];
 
let state = this.state;
const body = [];
  state.brandList.map((e,i)=>{
  console.log('YYYYYYYYYYYYYYYYY',e.brandName);
      body.push({
     'brand':e.brandName,
    //  'image' : e.file,
      'action': <div className="actiontrans" > 
       <Link to = "#" > <i className="fa fa-edit"></i></Link>
       {/* <Link to = "#"  onClick = {this.deleteSubCategory.bind(this,e._id)}  > <i className="fa fa-trash"></i></Link>  */}
       </div>  });
})
 console.log('Hello',body);
const onSortFunction = {
  date(columnValue) {
    // Convert the string date format to UTC timestamp
    // So the table could sort it by number instead of by string
    return moment(columnValue, 'Do MMMM YYYY').valueOf();
  },
};
 
const customLabels = {
  first: '<<',
  last: '>>',
  prev: '<',
  next: '>',
  show: 'Display',
  entries: 'rows',
  noResults: 'There is no data to be displayed',
};
 
// In your render method
return(
  <div className="salam_datatabl">
<Datatable
  tableHeader={header}
  tableBody={body}
  keyName="userTable"
  tableClass="striped hover responsive"
  rowsPerPage={5}
  rowsPerPageOption={[5, 10, 15, 20]}
  initialSort={{prop: "username", isAscending: true}}
  onSort={onSortFunction}
  labels={customLabels}
/>
</div>
  )
 }
}



export default BrandDataTable;