import React from 'react';
import ReactDOM from 'react-dom';
import {withRouter} from 'react-router-dom';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import validator from 'validator';
import './vendordetailpage.css';
import axios from 'axios';
import action from '../action/action';
const URL = process.env.REACT_APP_LOCAL;

class Vendordetailpage extends React.Component{

  constructor(props){
    super(props); 
     this.state = {
       status : {value : this.props.adminStatus , isValidate : true , message : ''},
     }
     this.handleChangeStatus = this.handleChangeStatus.bind(this);
     this.submit = this.submit.bind(this);
  }

  handleChangeStatus(event){
    const {name,value} = event.target;
    let state = this.state;
    state[name].message = '';
    state[name].value = value;
    this.setState(state);
  }

  // validate(){
  //   let state = this.state;
  //   if(validator.isEmpty(state.status.value)){
  //     state.status.isValidate = false;
  //     state.status.message = 'Select The Status';
  //     return false;
  //   }
  //   return true;
  // }

  submit(event){
    event.preventDefault();
    let obj = {};
    obj.vendorId = this.props.vendorId;
    obj.status = this.state['status'].value;
    console.log('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~',obj);

    axios.post(URL+'/api/editVendorList',obj).then((response)=>{
      console.log('WWWWWWWWWWWWWWWWWW',response);
      if(response.data.status === true){
        axios.post(URL+'/api/fetchVendor',obj).then((doc)=>{
          if(doc){
            this.props.authenticate({
              type : 'authenticate',
              payload : doc.data
            })
          }
        })
        alert(response.data.message)
      }else{
        alert(response.data.message)
      }
    })
    // window.location = '/Vendordetail';
  }

	render(){
    const state = this.state;
    console.log('#############',state.status.value);

		return(
        <div className="my-3 my-md-5">
          <div className="container">
            <div className="page-header">
              <h4 className="page-title">Vendor Detail</h4>
              <ol className="breadcrumb">
                <li className="breadcrumb-item"><a href="/Dashboard">Home</a></li>
                <li className="breadcrumb-item active" aria-current="page">Vendor Detail</li>
              </ol>
            </div>
            <div className="row">
              <div className="col-md-12">
                <div className="card card-profile vendorprofile">
                  <div className="card-body text-center">
                    <img className="card-profile-img" src={this.props.image} alt="img"/>
                    <h3 className="mb-3 text-white">{this.props.name}</h3>
                    <p className="mb-4 text-white">{this.props.accountType}</p>
                    {/* <a href="/createprofile" className="btn btn-warning btn-sm"><i className="fa fa-pencil"></i> Edit profile</a> */}
                  </div>
                </div>
              </div>
              <div className="col-lg-4">
                <div className="card p-5 ">
                  <div className="card-title">
                    Vendor Detail
                  </div>
                  <div className="media-list">
                    <div className="media mt-1 pb-2">
                      <div className="mediaicon">
                        <i className="fa fa-home" aria-hidden="true"></i>
                      </div>
                      <div className="media-body ml-5 mt-1">
                        <h6 className="mediafont text-dark">Address</h6> {this.props.streetName} {this.props.city} {this.props.address}
                      </div>
                    </div>
                    <div className="media mt-1 pb-2">
                      <div className="mediaicon">
                        <i className="fa fa-envelope-o" aria-hidden="true"></i>
                      </div>
                      <div className="media-body ml-5 mt-1">
                        <h6 className="mediafont text-dark">Email Address</h6><span className="d-block">{this.props.email}</span>
                      </div>
                    </div>
                    <div className="media mt-1 pb-2">
                      <div className="mediaicon">
                        <i className="fa fa-phone" aria-hidden="true"></i>
                      </div>
                      <div className="media-body ml-5 mt-1">
                         <h6 className="mediafont text-dark">Mobile No</h6><span className="d-block">{this.props.mobile}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-8">
                <div className="card">
                  <div className="card-body">
                    <div className=" " id="profile-log-switch">
                      <div className="fade show active " >
                        <div className="table-responsive border ">
                          <table className="table row table-borderless w-100 m-0 ">
                            <tbody className="col-lg-6 p-0">
                              <tr>
                                <td><strong>Full Name :</strong> {this.props.name} </td>
                              </tr>
                              <tr>
                                <td><strong>Location :</strong> {this.props.city}</td>
                              </tr>
                              <tr>
                                <td><strong>Address :</strong> {this.props.streetName} {this.props.city} {this.props.address}</td>
                              </tr>
                              <tr>
                                <td>
                               <select className="form-control custom-select" name = "status" value = {state.status.value} onChange = {this.handleChangeStatus}>
                               <option value = '' >{this.props.adminStatus}</option>
                                  {/* <option>Unverify</option> */}
                                  <option>Verify</option>
                                  <option>Block</option>
                                  {/* <option>UnBlock</option> */}
                                  </select>
                                 </td>
                              </tr>
                            </tbody>
                            <tbody className="col-lg-6 p-0">
                              <tr>
                                <td><strong> Store Email-id :</strong> {this.props.storeEmail}</td>
                              </tr>
                              <tr>
                                <td><strong>Email Id :</strong> {this.props.email} </td>
                              </tr>
                              <tr>
                                <td><strong>Phone Number :</strong> {this.props.mobile} </td>
                              </tr>
                              <tr>
                                <td><button onClick = {this.submit}>Submit</button> </td>
                              </tr>
                            </tbody>
                          </table>
                        </div>
                        {/* <div className="row mt-5 profie-img">
                          <div className="col-md-12">
                            <div className="media-heading">
                            <h5><strong>About Vendor</strong></h5>
                          </div>
                           <p>
                             Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus</p>
                          <p >because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure.</p>
                          </div>
                        </div> */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>


			)
	}
}

function mapStateToProps(state){
  console.log('ststae',state.inititateState);
  return {
    authenticateState :  state.inititateState.authenticateState,
    email : state.inititateState.email,
    accountType : state.inititateState.accountType,
    name : state.inititateState.name,
    mobile : state.inititateState.mobile,
    image : state.inititateState.image,
    vendorId : state.inititateState.vendorId,
    adminStatus : state.inititateState.adminStatus,
    address : state.inititateState.address,
    city : state.inititateState.city,
    streetName : state.inititateState.streetName,
    storeEmail : state.inititateState.storeEmail
  }
}

function mapDispatchToProps(dispatch){
  return {
    authenticate : bindActionCreators(action.authenticate , dispatch)
  }
}

export default withRouter(connect(mapStateToProps , mapDispatchToProps)(Vendordetailpage));